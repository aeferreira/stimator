
import math

def test(valueexpr, consts= {"c1":1.0, "c2":2.0, "c3":0.0}):
    locs = consts.copy()
    #part 1: nonpermissive, except for NameError
    try :
       value = float(eval(valueexpr, vars(math), locs))
    except NameError:
       pass
    except Exception, e:
       print "'%s' has an error!" % valueexpr
       print e.__class__.__name__," : ", e
       print
       return

    #part 2: permissive, with dummy values for vars and parameters
    for i,j in [("x",1.0),("y", 2.0),("k1", 3.14)]:
       locs[i]=j
    try :
       value = float(eval(valueexpr, vars(math), locs))
    except (ArithmeticError, ValueError):
       print "ok, but %s might fail..." % (valueexpr)
       print
       return
    except Exception, e:
       print "'%s' has an error!" % valueexpr
       print e.__class__.__name__," : ", e
       print
       return

    print "ok:", valueexpr, "=", value
    print

consts = {"c1":1.0, "c2":2.0, "c3":0.0}

expr = "2 * c2 + 7"
test(expr)

expr = "2 / c3 + 7"
test(expr)

expr = "2 * x + 7"
test(expr)

expr = "(2 * x + 7"
test(expr)

expr = "(2 * c1 + 7"
test(expr)

expr = "2 * c1 + 7 *"
test(expr)

expr = "1e-14e3"
test(expr)

expr = "(-c1)**(0.521)"
test(expr)

expr = "acos(2.5)"
test(expr)

expr = "sin(c1+c3)"
test(expr)

expr = "1e1400**10000"
test(expr)

expr = "1.0/(x-1.0)"
test(expr)

expr = "x * 1e1400**10000"
test(expr)

expr = "acos(y)"
test(expr)
