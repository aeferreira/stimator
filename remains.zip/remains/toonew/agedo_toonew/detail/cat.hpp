//
//  Copyright (c) 2005 João Abecasis
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//

#if !defined(AGEDO_DETAIL_CAT_HPP_INCLUDED)
#define AGEDO_DETAIL_CAT_HPP_INCLUDED

#define AGEDO_PP_CAT(a, b) AGEDO_PP_CAT_I(a, b)
#define AGEDO_PP_CAT_I(a, b) a ## b

#endif // include guard
