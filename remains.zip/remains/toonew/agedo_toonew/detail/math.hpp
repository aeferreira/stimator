//
//  Copyright (c) 2005 João Abecasis
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//

#if !defined(AGEDO_DETAIL_MATH_HPP_INCLUDED)
#define AGEDO_DETAIL_MATH_HPP_INCLUDED

#include <cstdlib>
#include <cmath>

#if defined(__BORLANDC__) && (__BORLANDC__ <= 0x551)

#   define AGEDO_math_function_overload1(function)                              \
        inline long double function(long double __x)                            \
        {                                                                       \
            return function ## l (__x);                                         \
        }

#   define AGEDO_math_function_overload2(function)                              \
        inline long double function(long double __x, long double __y)           \
        {                                                                       \
            return function ## l (__x, __y);                                    \
        }

#   define AGEDO_math_function_overload3(function)                              \
        inline long double function(long double __x, long double * __y)         \
        {                                                                       \
            return function ## l (__x, __y);                                    \
        }

#   define AGEDO_math_function_overload4(function)                              \
        inline long double function(long double __x, int __exponent)            \
        {                                                                       \
            return function ## l (__x, __exponent);                             \
        }

#   define AGEDO_math_function_overload5(function)                              \
        inline long double function(long double __x, int * __exponent)          \
        {                                                                       \
            return function ## l (__x, __exponent);                             \
        }

namespace std {

    //  NOTE: Adding overloads in namespace std is a violation of the standard.
    //      Then again, the missing overloads defined here are also a violation
    //      thereof.

    AGEDO_math_function_overload1(acos)    // (long double __x);
    AGEDO_math_function_overload1(asin)    // (long double __x);
    AGEDO_math_function_overload1(atan)    // (long double __x);
    AGEDO_math_function_overload2(atan2)   // (long double __y, long double __x);
    AGEDO_math_function_overload1(ceil)    // (long double __x);
    AGEDO_math_function_overload1(cos)     // (long double __x);
    AGEDO_math_function_overload1(cosh)    // (long double __x);
    AGEDO_math_function_overload1(exp)     // (long double __x);
    AGEDO_math_function_overload1(fabs)    // (long double __x);
    AGEDO_math_function_overload1(floor)   // (long double __x);
    AGEDO_math_function_overload2(fmod)    // (long double __x, long double __y);
    AGEDO_math_function_overload5(frexp)   // (long double __x, int * __exponent);
    AGEDO_math_function_overload4(ldexp)   // (long double __x, int __exponent);
    AGEDO_math_function_overload1(log)     // (long double __x);
    AGEDO_math_function_overload1(log10)   // (long double __x);
    AGEDO_math_function_overload3(modf)    // (long double __x, long double * __ipart);
    AGEDO_math_function_overload2(pow)     // (long double __x, long double __y);
    AGEDO_math_function_overload1(sin)     // (long double __x);
    AGEDO_math_function_overload1(sinh)    // (long double __x);
    AGEDO_math_function_overload1(sqrt)    // (long double __x);
    AGEDO_math_function_overload1(tan)     // (long double __x);
    AGEDO_math_function_overload1(tanh)    // (long double __x);

    inline double abs(double __x)
    {
        return fabs(__x);
    }

    inline long double abs(long double __x)
    {
        return fabsl(__x);
    }

    inline long abs(long __x)
    {
        return labs(__x);
    }

    inline ldiv_t div(long __numer, long __denom)
    {
        return ldiv(__numer, __denom);
    }

    inline double pow(double __x, int __y)
    {
        if (__y < 0)
        {
            __x = 1. / __x;
            __y = - __y;
        }

        double __result = (__y % 2) ? __x : 1.0;

        while (__y >>= 1)
        {
           __x *= __x;

           if (__y % 2)
               __result *= __x;
        }

        return __result;
    }

} // namespace std

#   undef AGEDO_math_function_overload1
#   undef AGEDO_math_function_overload2
#   undef AGEDO_math_function_overload3
#   undef AGEDO_math_function_overload4
#   undef AGEDO_math_function_overload5

#endif

#endif // include guard
