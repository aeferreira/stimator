//
//  Copyright (c) 2005 João Abecasis
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//

#if !defined(AGEDO_DETAIL_STATIC_ASSERT_HPP_INCLUDED)
#define AGEDO_DETAIL_STATIC_ASSERT_HPP_INCLUDED

#include <agedo/detail/cat.hpp>

#define AGEDO_STATIC_ASSERT(condition)                                          \
    enum                                                                        \
    {                                                                           \
        AGEDO_PP_CAT(assertion_result_in_line_, __LINE__)                       \
            = ::agedo::static_assert< (condition) >::assertion_success;         \
    }

namespace agedo {

    template <bool Value> struct static_assert;
    template <> static_assert<true> { enum { assertion_success = true }; };

} // namespace agedo

#endif // include guard
