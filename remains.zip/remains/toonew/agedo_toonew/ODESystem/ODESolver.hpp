//
// Copyright (c) 2003-2005 João Abecasis
//

#ifndef _agedo_ODESOLVER_H
#define _agedo_ODESOLVER_H

#include <agedo/ODESystem/ODESystem.hpp>

class ODESolver
{
protected:
    ODESystem& ODEs;
public:
    ODESolver(ODESystem& sys) : ODEs(sys)
    {
    }

    virtual ~ODESolver()
    {
    };

    virtual int Solve(const double &time) = 0;
};

#endif
