//
//  Copyright (c) 2005 João Abecasis
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//

#if !defined(AGEDO_DETAIL_COUNT_INSTANCES_HPP_INCLUDED)
#define AGEDO_DETAIL_COUNT_INSTANCES_HPP_INCLUDED

#include <cstddef>

namespace agedo { namespace detail {

    template <typename Tag>
    struct count_instances
    {
        typedef std::size_t size_type;

        count_instances()
        {
            ++count_;
        }

        count_instances(count_instances<Tag> const &)
        {
            ++count_;
        }

        ~count_instances()
        {
            --count_;
        }

        static size_type count()
        {
            return count_;
        }

    private:
        static size_type count_;
    };

    template <typename Tag>
    count_instances<Tag>::size_type count_instances<Tag>::count_ = 0;

}} // namespace agedo::detail

#endif // include guard
