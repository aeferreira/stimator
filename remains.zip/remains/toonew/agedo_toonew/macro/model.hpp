//
//  Copyright (c) 2005 João Abecasis
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//

#if !defined(AGEDO_MACRO_MODEL_HPP_INCLUDED)
#define AGEDO_MACRO_MODEL_HPP_INCLUDED

#include <agedo/macro/variable.hpp>

#include <agedo/ODESystem/ODESystem.hpp>

namespace agedo { namespace macro {

    template <typename Derived>
    struct model_base
        : ODESystem
    {
        model_base()
            : ODESystem(static_variable_count(), dynamic_variable_count())
        {
        }

    private:
        struct dynamic_variable_tag;
        struct static_variable_tag;

    protected:
        typedef variable<dynamic_variable_tag> dynamic_variable;
        typedef variable<static_variable_tag> static_variable;

    private:
        static std::size_t static_variable_count()
        {
            return static_variable::count();
        }

        static std::size_t dynamic_variable_count()
        {
            return dynamic_variable::count();
        }
    };

}} // namespace agedo::macro

#endif // include guard
