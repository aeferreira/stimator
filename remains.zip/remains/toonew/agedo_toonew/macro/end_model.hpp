//
//  Copyright (c) 2005 João Abecasis
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//

//
//               !! THIS FILE HAS NO INCLUDE GUARDS !!
//
// This file is meant to be included multiple times by the framework.
//

    }; // struct AGEDO_MACRO_MODEL_NAME

} // namespace agedo::model

#include <agedo/macro/undef_macros.hpp>

