//
// Copyright (c) 2003-2005 João Abecasis
//

#ifndef _agedo_LINEAR_ALGEBRA_H
#define _agedo_LINEAR_ALGEBRA_H

#include <agedo/detail/math.hpp>

#include <algorithm>

namespace LSODA { namespace LinearAlgebra {

    // weighted max-norm of vector of length n
    //   = max(i=0...n-1)( abs(vector[i]) * weight[i] )
    template<typename value_type, typename size_type>
    inline value_type VectorMaxNorm(size_type n, const value_type * const vector, const value_type * const weight)
    {
        using std::abs;

        --n;
        value_type temp, vmax = abs(vector[n]) * weight[n];

        while (--n >= 0)
        {
            temp = abs(vector[n]) * weight[n];
            temp > vmax ? vmax = temp : 0;
        }
        return vmax;
    }

    // weighted max-norm of n by n matrix
    //   = max(i=0...n-1)( weight[i] * sum(j=0...n-1)( abs(matrix[i + j*n]) / weight[j] ) )
    template<typename value_type, typename size_type>
    inline value_type MatrixMaxNorm(const size_type n, const value_type * matrix, const value_type * const weight)
    {
        using std::abs;

        size_type i = 0, j;
        value_type temp, mmax = 0;

        for (; i < n; ++i, ++matrix)
        {
            for (j = 0, temp = value_type(0); j < n ; ++j)
            {
                temp += abs(matrix[j*n]) / weight[j];
            }

            temp *= weight[i];
            temp > mmax ? mmax = temp : 0;
        }

        return mmax;
    }

    // max-norm of banded n by n matrix
    // This function computes the norm of a banded N by N matrix,
    // stored in the array MATRIX, that is consistent with the weighted max-norm
    // on vectors, with weights stored in the array WEIGHT.
    // ML and MU are the lower and upper half-bandwidths of the matrix.
    // NRA is the first dimension of the A array, NRA >= ML+MU+1.
    // In terms of the matrix elements a[i,j], the norm is given by:
    //   = max(i=0...n-1) ( weight[i] * sum(j=0...n-1)( abs( matrix[i,j] ) / weight[j] ) )
    template<typename value_type, typename size_type>
    inline value_type BandedMatrixMaxNorm(const size_type n, const value_type * const matrix, const size_type nRows, const size_type ml, const size_type mu, const value_type * const weight)
    {
        using std::min;
        using std::max;
        using std::abs;

        size_type i = 0, j, jHi;
        value_type temp, mmax = 0;

        for (; i < n; ++i)
        {
            temp = value_type(0);
            jHi = min(i + mu + 1, n);

            for (j = max(i - ml, size_type(0)); j < jHi; ++j)
            {
                temp += abs(matrix[i + mu - j + j * nRows]) / weight[j];
            }

            temp *= weight[i];
            temp > mmax ? mmax = temp: 0 ;
        }

        return mmax;
    }

    // find the smallest (1-based) index of that component of a vector having the maximum magnitude
    //    = min(i=0...n-1) : vector[i] == max(j=0...n-1)( abs(vector[j-1]) )
    //    returns 0 if n <= 0;
    template<typename value_type, typename size_type>
    inline size_type IndexOfMax(const size_type n, const value_type * vector)
    {
        using std::abs;

        if (n <= 0)
            return 0;

        if (n == 1)
            return 1;

        --vector;

        size_type ret_val = 1;

        value_type temp, vmax = abs(vector[1]);

        for (size_type i = 1; i <= n; ++i)
        {
            temp = abs(vector[i]);
            temp > vmax ? (ret_val = i, vmax = temp) : 0;
        }

        return ret_val;
    }

    // compute a constant times a vector
    //   sets : (i=0...n-1) ( X[i] = A * X[i] )
    template<typename value_type, typename size_type>
    inline void AX(size_type n, const value_type &A, value_type * const X)
    {
        while (--n >= 0)
        {
            X[n] *= A;
        }
    }

    // compute a constant times a vector plus a vector
    //   sets : (i=0...n-1)( Y[i] = A * X[i] + Y[i] )
    template<typename value_type, typename size_type>
    inline void AXplusY(size_type n, const value_type &A, const value_type * const X, value_type * const Y)
    {
        while (--n >= 0)
        {
            Y[n] += A * X[n];
        }
    }

    // compute the inner product of two vectors
    //   = sum(i=1...n)( X[i] * Y[i] )
    template<typename value_type, typename size_type>
    inline value_type DotProduct(size_type n, const value_type * const X, const value_type * const Y)
    {
        value_type ret_val = 0;

        while (--n >= 0)
        {
            ret_val += X[n] * Y[n];
        }

        return ret_val;
    }

} /* LinearAlgebra */ } /* LSODA */

#endif
