        #self.ModelEditorSetBufferedDraw(False)
        #self.ModelEditorStyleClearAll()
        #self.ModelEditorSetScrollWidth(800)
        #self.ModelEditorSetWrapMode(True)
        #self.ModelEditorSetUseAntiAliasing(False)
        #self.ModelEditorSetViewEOL(True)

        #self.ModelEditorCmdKeyClear(stc.STC_KEY_BACK,
        #               stc.STC_SCMOD_CTRL)
        #self.ModelEditorCmdKeyAssign(stc.STC_KEY_BACK,
        #                stc.STC_SCMOD_CTRL,
        #                stc.STC_CMD_DELWORDLEFT)

        self.ModelEditor.SetText(demoText)
        self.ModelEditor.EmptyUndoBuffer()


        # make some styles
        self.ModelEditor.StyleSetSpec(stc.STC_STYLE_DEFAULT, "size:%d,face:%s" % (pb, face3))
        self.ModelEditor.StyleClearAll()
        self.ModelEditor.StyleSetSpec(1, "size:%d,bold,face:%s,fore:#0000FF" % (pb+2, face1))
        self.ModelEditor.StyleSetSpec(2, "face:%s,italic,fore:#FF0000,size:%d" % (face2, pb))
        self.ModelEditor.StyleSetSpec(3, "face:%s,bold,size:%d" % (face2, pb+2))
        self.ModelEditor.StyleSetSpec(4, "face:%s,size:%d" % (face1, pb-1))

        # Now set some text to those styles...  Normally this would be
        # done in an event handler that happens when text needs display self.ModelEditor
        self.ModelEditor.StartStyling(98, 0xff)
        self.ModelEditor.SetStyling(6, 1)  # set style for 6 characters using style 1

        self.ModelEditor.StartStyling(190, 0xff)
        self.ModelEditor.SetStyling(20, 2)

        self.ModelEditor.StartStyling(310, 0xff)
        self.ModelEditor.SetStyling(4, 3)
        self.ModelEditor.SetStyling(2, 0)
        self.ModelEditor.SetStyling(10, 4)


        # line numbers in the margin
        self.ModelEditor.SetMarginType(0, stc.STC_MARGIN_NUMBER)
        self.ModelEditor.SetMarginWidth(0, 22)
        self.ModelEditor.StyleSetSpec(stc.STC_STYLE_LINENUMBER, "size:%d,face:%s" % (pb, face1))

        # setup some markers
        self.ModelEditor.SetMarginType(1, stc.STC_MARGIN_SYMBOL)
        self.ModelEditor.MarkerDefine(0, stc.STC_MARK_ROUNDRECT, "#CCFF00", "RED")
        self.ModelEditor.MarkerDefine(1, stc.STC_MARK_CIRCLE, "FOREST GREEN", "SIENNA")
        self.ModelEditor.MarkerDefine(2, stc.STC_MARK_SHORTARROW, "blue", "blue")
        self.ModelEditor.MarkerDefine(3, stc.STC_MARK_ARROW, "#00FF00", "#00FF00")

        # put some markers on some lines
        self.ModelEditor.MarkerAdd(17, 0)
        self.ModelEditor.MarkerAdd(18, 1)
        self.ModelEditor.MarkerAdd(19, 2)
        self.ModelEditor.MarkerAdd(20, 3)
        self.ModelEditor.MarkerAdd(20, 0)


        # and finally, an indicator or two
        self.ModelEditor.IndicatorSetStyle(0, stc.STC_INDIC_SQUIGGLE)
        self.ModelEditor.IndicatorSetForeground(0, wx.RED)
        self.ModelEditor.IndicatorSetStyle(1, stc.STC_INDIC_DIAGONAL)
        self.ModelEditor.IndicatorSetForeground(1, wx.BLUE)
        self.ModelEditor.IndicatorSetStyle(2, stc.STC_INDIC_STRIKE)
        self.ModelEditor.IndicatorSetForeground(2, wx.RED)

        self.ModelEditor.StartStyling(836, stc.STC_INDICS_MASK)
        self.ModelEditor.SetStyling(10, stc.STC_INDIC0_MASK)
        self.ModelEditor.SetStyling(10, stc.STC_INDIC1_MASK)
        self.ModelEditor.SetStyling(10, stc.STC_INDIC2_MASK | stc.STC_INDIC1_MASK)

